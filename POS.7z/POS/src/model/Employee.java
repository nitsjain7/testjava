package model;

public class Employee extends User{
	
}
