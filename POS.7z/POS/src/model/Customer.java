package model;

/**
 * @author niyatee.jain Customer class
 *
 */
public class Customer extends User {

}