package model;

/**
 * @author niyatee.jain : Affiliate Class
 *
 */
public class Affiliate extends User {

}
